 
 const buttons = document.querySelectorAll('[data-box]');


  buttons.forEach((button) => {
  button.addEventListener('click', showBox);
});

  function showBox(event) {
  if (clicked) {
    return;
  }
  const { box } = event.target.dataset;
  const boxElement = document.getElementById(box);
  
  const animation = randomAnimation();

  boxElement.style.zIndex = 9;
  boxElement.style.transform = 'scale(1.16)';
  lastAnimation = animation;
  
  boxElement.classList.toggle(animation);
  clicked = true;
  return boxElement.classList.remove(boxElement.classList[1]);
}